from django.shortcuts import render
from rest_framework.decorators import api_view
from .serializers import UserSerializer
from .models import User
from .mails import send_verify_mail, send_password_mail
from rest_framework.response import Response
from rest_framework.exceptions import AuthenticationFailed
from rest_framework import status
from django.http import HttpResponse, HttpResponseRedirect
import jwt, datetime
from .logs import logger

# Create your views here.

key = 'hello_world'


def generate_url(email_id, action):
    payload = {
        'email' : email_id,
        'exp' : datetime.datetime.utcnow() + datetime.timedelta(minutes=5),
        'iat' : datetime.datetime.utcnow()
    }

    token = jwt.encode(payload, key, algorithm='HS256').decode('utf-8')
    if action == 'verify':
        url = 'http://localhost:8000/user/verify_user?token='+token
    elif action == 'reset':
        url = 'http://localhost:8000/user/reset_password?token='+token
    
    logger.info("Url is created \n url-->",url)

    return url

def home(request):
    return HttpResponseRedirect("http://localhost:8000/user/login/")

@api_view(['GET', 'POST'])
def register_user(request):
    if request.method == 'POST':
        serializer = UserSerializer(data=request.data)

        if request.POST.get('password') != request.POST.get('confirm_password'):
            logger.info("Different passwords entered")
            raise serializer.ValidationError('Password must be same')

        if serializer.is_valid():
            user = serializer.save()
            logger.info("user created with is_verified value as False")

            email = user.email
            url = generate_url(email, 'verify')
            send_verify_mail(url,email)
            return HttpResponse("<h1>Verification mail sent</h1>")
        
        logger.error(serializer.errors)
        return Response(serializer.errors)
    else:
        logger.info("Request for fetching Register-page.html")
        return render(request, 'project1/Register-page.html')

@api_view(['POST', 'GET'])
def verify_user(request):
    token = request.query_params['token']
    payload = jwt.decode(token, key, algorithm='HS256')

    user = User.objects.get(email = payload['email'])

    if user is None:
        logger.error("User verification unsuccessful")
        raise AuthenticationFailed('Un authorised')

    user.is_verified = True
    user.save()
    logger.info("User verified and is_verified field value updated to",user.is_verified)
    return HttpResponseRedirect("/user/login/")

@api_view(['GET', 'POST'])
def login_user(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        # user = User.objects.filter(email=email).first()
        user = User.objects.get(email=email)

        print("email is ",email)
        print("user is ",user)

        if user is None:
            logger.error("User not found")
            raise AuthenticationFailed('User not found')

        if not user.check_password(password):
            logger.error("Incorrect password")
            raise AuthenticationFailed('Incorrect password')

        if getattr(user, 'is_verified') != True:
            logger.error("Current User is not verified")
            raise AuthenticationFailed('Current User is not verified')

        payload = {
            'id':user.id,
            'role':user.role,
            'exp':datetime.datetime.utcnow() + datetime.timedelta(minutes=60),
            'iat':datetime.datetime.utcnow()
        }

        
        token = jwt.encode(payload, key, algorithm ='HS256').decode('utf-8')

        logger.info("login jwt token created \ntoken -->",token)


        response = HttpResponseRedirect("http://localhost:8000/user/myprofile/")

        response.set_cookie(key='token', value=token, httponly=True)
        logger.info("Token set to cookies with key 'token'")
        
        return response

    else:
        logger.info("Request for fetching login-page.html")
        return render(request, 'project1/login-page.html')



@api_view(['GET', 'POST'])
def forgot_password(request):
    if request.method == 'POST':
        email = request.data['email']

        if User.objects.filter(email=email).exists():
            url = generate_url(email, 'reset')
            send_password_mail(url,email)
            return render(request, 'project1/forget_password.html',{'status':'mail sent successfully'})
        else:
            logger.error("Forgot password mail doesn't send as the user not exists")
            return render(request, 'project1/forget_password.html',{'status':'User not exists'})
    else:
        logger.info("Request for fetching forget_password.html")
        return render(request, 'project1/forget_password.html')

        

@api_view(['GET', 'POST'])
def reset_password(request):
    if request.method == 'POST':
    #     token = request.query_params['token']
    #     payload = jwt.decode(token, key, algorithm='HS256')

    #     user = User.objects.get(email = payload['email'])

    #     if user is None:
    #         raise AuthenticationFailed('Un authorised')

    #     print(request.data)
    #     pswd1 = request.data['new_password']
    #     pswd2 = request.data['confirm_password']

    #     if pswd1==pswd2:
    #         user.set_password(pswd1)
    #         user.save()
    #         return Response({'msg':'Password updated!'}, status=status.HTTP_200_OK)
    #     return Response({'msg':"confirm password doesn't match"}, status=status.HTTP_400_BAD_REQUEST)
        pass
    else:
        logger.info("Request for fetching reset_password.html")
        return render(request, 'project1/reset_password.html')

@api_view(['GET', 'POST'])
def logout_user(request):
        response = HttpResponseRedirect("http://localhost:8000/user/login/")
        response.delete_cookie('token')
        logger.info("Session expired")
        return response


def get_user(request):
        token = request.COOKIES.get('token', None)

        if token==None:
            logger.error("Token not exist")
            return HttpResponseRedirect("http://localhost:8000/user/login/")

        try:
            payload = jwt.decode(token, key, algorithm ='HS256')
        except jwt.ExpiredSignatureError:
            return HttpResponseRedirect("http://localhost:8000/user/login/")

        user = User.objects.get(id=payload['id'])

        logger.info("Request for User details")
        return render(request, 'project1/my_profile.html',{'user':user})