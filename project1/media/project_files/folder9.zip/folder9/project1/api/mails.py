from django.core.mail import send_mail
from .logs import logger

def send_verify_mail(url, recipient):
    url = 'Hi, \n\n Please find verification url below\n\n' + url
    try:
        send_mail(
            'Verification mail for sign-up',
            url,
            'jaypalla23@gmail.com',
            [recipient]
        )
    except Exception as e:
        logger.error(e)

def send_password_mail(url, recipient):
    url = 'Hi, \n\n Please find password reset url below\n\n' + url
    try:
        send_mail(
            'Password reset mail',
            url,
            'jaypalla23@gmail.com',
            [recipient]
        )
    except Exception as e:
        logger.error(e)