# from django.contrib import admin
from django.urls import path, include
from .views import  login_user, register_user, verify_user, forgot_password, logout_user, get_user, reset_password#, change_password

urlpatterns = [
    path('register/', register_user),
    path('login/', login_user),
    path('myprofile/', get_user),
    path('logout/', logout_user),
    path('verify_user/', verify_user),
    # path('change_password', change_password),
    path('forgot_password/', forgot_password),
    path('reset_password', reset_password),
]