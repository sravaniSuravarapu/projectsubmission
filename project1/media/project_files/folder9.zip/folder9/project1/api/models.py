from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.

class User(AbstractUser):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    role = models.CharField(max_length=10)
    gender = models.CharField(max_length=6)
    email = models.CharField(max_length=255, unique=True)
    personal_email = models.CharField(max_length=255, unique=True, null=True, blank=True)
    dob = models.CharField(max_length=10)
    mobile = models.CharField(max_length=13)
    password = models.CharField(max_length=255)
    is_active = models.BooleanField(default=False)
    is_verified = models.BooleanField(default=False)
    
    username = None

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []
