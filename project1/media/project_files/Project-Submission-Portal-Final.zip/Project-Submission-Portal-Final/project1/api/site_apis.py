from urllib import response
from django.shortcuts import redirect, render
from rest_framework.decorators import api_view
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser, FileUploadParser
from .serializers import ProjectRegistrationSerializer, ProjectSubmissionSerializer, NotificationsSerializer
from .models import User, ProjectRegistration, ProjectSubmission, Notifications
from .mails import send_verify_mail, send_password_mail
from project1.settings import key, MEDIA_ROOT
from rest_framework.response import Response
from rest_framework.exceptions import AuthenticationFailed
from rest_framework import status
from django.http import HttpResponse, HttpResponseRedirect, FileResponse
from django.contrib import messages
from django.contrib.auth.decorators import login_required
import jwt, datetime
from .logs import logger
from rest_framework.views import APIView
import pytz


def display_dashboard(request):
    token = request.COOKIES.get('token', None)

    if token==None:
        logger.error("Token not exist")
        return redirect("login-page")

    try:
        payload = jwt.decode(token, key, algorithms=['HS256'])
        print(payload)
    except jwt.ExpiredSignatureError:
        return redirect("login-page")

    user = User.objects.filter(email=payload['email']).first()

    if payload['role'] == 'student':
        faculty = User.objects.filter(role = 'faculty', branch = user.branch).all()
        projects = ProjectSubmission.objects.filter(clg_id = user.clg_id).all()

        return render(request, 'project1/student-dashboard.html', {'user':user, 'faculty':faculty, 'projects':projects})
    elif payload['role'] == 'faculty':

        faculty_name = user.first_name + " " + user.last_name
        registered = ProjectRegistration.objects.filter(faculty = faculty_name).all()
        submitted = ProjectSubmission.objects.filter(faculty = faculty_name).all()
        submitted_list = list(submitted.values())
        registered_list = list(registered.values())
        
        rcountDict = {
            'Puc1' : 0,
            'Puc2' : 0,
            'E1' : 0,
            'E2' : 0,
            'E3' : 0,
            'E4' : 0
        }

        scountDict = {
            'Puc1' : 0,
            'Puc2' : 0,
            'E1' : 0,
            'E2' : 0,
            'E3' : 0,
            'E4' : 0
        }

        for j in registered_list:
            student = User.objects.filter(clg_id = j['clg_id']).first()
            j.update({'name': student.first_name + ' ' + student.last_name })
            rcountDict[j['aca_year']] += 1

        rCountList = list(rcountDict.values())
            

        for i in submitted_list:
            student = User.objects.filter(clg_id = i['clg_id']).first()
            i.update({'branch': student.branch, 'name': student.first_name + ' ' + student.last_name})
            scountDict[i['aca_year']] += 1
        
        sCountList = list(scountDict.values())

        overAllStats = [submitted.count(), (registered.count() - submitted.count())]

        return render(request, 'project1/faculty-dashboard.html', {'user':user, 'registered':registered_list, 'submitted':submitted_list, 'rCountList':rCountList, 'sCountList':sCountList, 'overAllStats':overAllStats})

def display_scoreboard(request):
    token = request.COOKIES.get('token', None)

    if token==None:
        logger.error("Token not exist")
        return redirect("login-page")

    try:
        payload = jwt.decode(token, key, algorithms=['HS256'])
        print(payload)
    except jwt.ExpiredSignatureError:
        return redirect("login-page")

    user = User.objects.filter(email=payload['email']).first()

    if payload['role'] == 'student':
        return render(request, 'project1/student_scoreboard.html', {'user':user})
    elif payload['role'] == 'faculty':
        return render(request, 'project1/faculty_scoreboard.html', {'user':user})


def display_about(request):
    return render(request, 'project1/about.html')


#student apis

def register_project(request):
    serializer = ProjectRegistrationSerializer(data=request.POST)

    user = ProjectRegistration.objects.filter(clg_id = request.POST.get('clg_id')).first()

    if user is not None:

        not_submitted = ProjectRegistration.objects.filter(clg_id = request.POST.get('clg_id'), is_submitted = 0).exists()

        if not_submitted:
            messages.error(request, "Already registered before")

        elif serializer.is_valid():
            serializer.save()
            logger.info(serializer.data)
            messages.success(request, "Project registration completed successfully")
            
        else:
            logger.error(serializer.errors)
            messages.error(request, "Project registration unsuccessful")
    
    else:
        if serializer.is_valid():
            serializer.save()
            logger.info(serializer.data)
            messages.success(request, "Project registration completed successfully")
        
        else:
            logger.error(serializer.errors)
            messages.error(request, "Project registration unsuccessful")

    return redirect('dashboard')

@api_view(['GET', 'POST'])
def submit_project(request):
    if request.method == 'POST':
        is_registered = ProjectRegistration.objects.filter(clg_id = request.data.get('clg_id'), is_submitted = 0).exists()

        if is_registered:
            parser_class = (FileUploadParser, )
            serializer = ProjectSubmissionSerializer(data=request.data)

            if serializer.is_valid():
                serializer.save()
                ProjectRegistration.objects.filter(clg_id = request.data.get('clg_id'), is_submitted = 0).update(is_submitted = 1)
                logger.info(serializer.data)
                messages.success(request, "Project submitted successfully")
            else:
                logger.error(serializer.errors)
                messages.error(request, "Project submition failed")
        else:
            logger.info("Student not registered any project under any faculty.")
            messages.warning(request, "Student not registered any project under any faculty.")
        
    return redirect('dashboard')


@api_view(['GET'])
def download_project(request):
    project = ProjectSubmission.objects.filter(project_id = request.query_params['id']).first()
    file_path = MEDIA_ROOT + str(project.project_file)
    response = FileResponse(open(file_path,'rb'))
    logger.info(response)

    return response


# Faculty Apis

@api_view(['POST','GET'])
def create_notifications(request):
    token = request.COOKIES.get('token', None)

    if token==None:
        logger.error("Token not exist")
        return redirect("login-page")

    try:
        payload = jwt.decode(token, key, algorithms=['HS256'])
        print(payload)
    except jwt.ExpiredSignatureError:
        return redirect("login-page")
    if request.method== 'POST':
        user = User.objects.filter(email=payload['email']).first()

        faculty_name = user.first_name + " " + user.last_name

        students_list = list(ProjectRegistration.objects.filter(faculty = faculty_name, is_submitted = 0).values('clg_id'))

        new_dict={}
        new_dict.update(request.data)
        for k in new_dict.keys():
            new_dict[k]=new_dict[k][0]

        for i in students_list:
            new_dict['clg_id']= i['clg_id']
            serializer = NotificationsSerializer(data = new_dict)
            print(serializer)
            if serializer.is_valid():
                serializer.save()
                logger.info(serializer.data)
            else:
                logger.error(serializer.errors)
                print("Serializer Erros : ",serializer.errors)
        if serializer.is_valid():
            messages.info(request, 'Work assigned successfully')
        else:
            messages.error(request, 'Work assignment failed')

        return redirect('dashboard')
    return render(request,'project1/faculty-dashboard.html')