#include <stdio.h>
#include <stdlib.h>

struct node{
    char data;
    struct node *nxt;
} *head = NULL;

int nodeCount = 0;

void display(){
    struct node *ptr = head;
    printf("The total nodes data is : ");

    while(ptr != NULL){
        printf("%c ", ptr->data);
        ptr = ptr->nxt;
    }
}

void create(){
    struct node *newnode, *ptr;

    printf("Enter the number of nodes to be created : ");
    scanf("%d", &nodeCount);

    for(int i = 1; i <= nodeCount; i++){
        newnode = (struct node*) malloc(sizeof(struct node));

        printf("Enter the data in the node-%d : ",i);
        getchar();
        scanf("%c",&newnode->data);

        if(head == NULL){
            head = ptr = newnode;
        }else{
            ptr->nxt = newnode;
            ptr = newnode;
        }
    }
    ptr->nxt = NULL;

    display();
}

void insert(){
    struct node *newnode, *ptr;
    int pos;

    printf("\nNote: Total no. of nodes present is %d\n", nodeCount);
    printf("Enter the position of insertion : ");
    scanf("%d", &pos);

    newnode = (struct node*) malloc(sizeof(struct node));

    printf("Enter the data in the node : ");
    getchar();
    scanf("%c",&newnode->data);

    if(pos == 1){
        newnode->nxt = head;
        head = newnode;
    }else if(pos == nodeCount+1){
        ptr = head;
        while(ptr->nxt != NULL){
            ptr = ptr->nxt;
        }
        ptr->nxt = newnode;
        newnode->nxt = NULL;
    }else{
        ptr = head;
        for(int i = 2; i < pos; i++){
            ptr = ptr->nxt;
        }
        newnode->nxt = ptr->nxt;
        ptr->nxt = newnode;
    }

    nodeCount++;

    display();
}

void deleteNode(){
    struct node *ptr, *qtr;
    int pos;

    printf("\nNote: Total no. of nodes present is %d\n", nodeCount);
    printf("Enter the position of deletion : ");
    scanf("%d", &pos);

    if(pos == 1){
        ptr = head;
        head = head->nxt;
        free(ptr);
    }else if(pos == nodeCount){
        ptr = head;

        while(ptr->nxt != NULL){
            qtr = ptr;
            ptr = ptr->nxt;
        }

        qtr->nxt = NULL;
        free(ptr);

    }else{
        ptr = head;

        for(int i = 1; i < pos; i++){
            qtr = ptr;
            ptr = ptr->nxt;
        }

        qtr->nxt = ptr->nxt;
        free(ptr);
    }

    nodeCount--;

    display();
}

void main()
{
    int opt;
    create();

    while(1){
        printf("\n\nSelect operation : \n1) Node Insertion \n2) Node deletion\n3) Exit\n--> ");
        scanf("%d", &opt);

        switch(opt){
            case 1:
                insert();
                break;
            case 2:
                deleteNode();
                break;
            case 3:
                exit(0);
                break;
            default:
                printf("\n\nEnter valid operation\n\n");
        }
    }
}
