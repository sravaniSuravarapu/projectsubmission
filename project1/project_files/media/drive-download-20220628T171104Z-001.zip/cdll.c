#include <stdio.h>
#include <stdlib.h>

struct node{
    char data;
    struct node *prev;
    struct node *nxt;
} *head = NULL;

int nodeCount = 0;

void display(){
    struct node *ptr = head;
    printf("The total nodes data is : ");

    do{
        printf("%c ", ptr->data);
        ptr = ptr->nxt;
    }while(ptr != head);
}

void create(){
    struct node *newnode, *ptr;

    printf("Enter the number of nodes to be created : ");
    scanf("%d", &nodeCount);

    for(int i = 1; i <= nodeCount; i++){
        newnode = (struct node*) malloc(sizeof(struct node));

        printf("Enter the data in the node-%d : ",i);
        getchar();
        scanf("%c",&newnode->data);

        if(head == NULL){
            head = ptr = newnode;
        }else{
            ptr->nxt = newnode;
            newnode->prev = ptr;
            ptr = newnode;
        }
    }
    head->prev = ptr;
    ptr->nxt = head;

    display();
}

void insert(){
    struct node *newnode, *ptr;
    int pos;

    printf("\nNote: Total no. of nodes present is %d\n", nodeCount);
    printf("Enter the position of insertion : ");
    scanf("%d", &pos);

    newnode = (struct node*) malloc(sizeof(struct node));

    printf("Enter the data in the node : ");
    getchar();
    scanf("%c",&newnode->data);

    if(pos == 1){
        ptr = head;

        while(ptr->nxt != head){
            ptr = ptr->nxt;
        }
        ptr->nxt = newnode;
        newnode->prev = ptr;
        newnode->nxt = head;
        head->prev = newnode;
        head = newnode;
    }else if(pos == nodeCount+1){
        ptr = head;
        while(ptr->nxt != head){
            ptr = ptr->nxt;
        }
        head->prev = newnode;
        newnode->nxt = head;
        newnode->prev = ptr;
        ptr->nxt = newnode;

    }else{
        ptr = head;
        for(int i = 2; i < pos; i++){
            ptr = ptr->nxt;
        }
        newnode->nxt = ptr->nxt;
        newnode->prev = ptr;
        ptr->nxt->prev = newnode;
        ptr->nxt = newnode;
    }

    nodeCount++;

    display();
}

void deleteNode(){
    struct node *ptr, *qtr;
    int pos;

    printf("\nNote: Total no. of nodes present is %d\n", nodeCount);
    printf("Enter the position of deletion : ");
    scanf("%d", &pos);

    if(pos == 1){
        ptr = qtr = head;

        while(qtr->nxt != head){
            qtr = qtr->nxt;
        }

        head = head->nxt;
        head->prev = qtr;
        qtr->nxt = head;
        free(ptr);

    }else if(pos == nodeCount){
        ptr = head;

        while(ptr->nxt != head){
            qtr = ptr;
            ptr = ptr->nxt;
        }
        head->prev = qtr;
        qtr->nxt = head;
        free(ptr);

    }else{
        ptr = head;

        for(int i = 1; i < pos; i++){
            ptr = ptr->nxt;
        }

        ptr->prev->nxt = ptr->nxt;
        ptr->nxt->prev = ptr->prev;
        free(ptr);
    }

    nodeCount--;

    display();
}

void main()
{
    int opt;
    create();

    while(1){
        printf("\n\nSelect operation : \n1) Node Insertion \n2) Node deletion\n3) Exit\n--> ");
        scanf("%d", &opt);

        switch(opt){
            case 1:
                insert();
                break;
            case 2:
                deleteNode();
                break;
            case 3:
                exit(0);
                break;
            default:
                printf("\n\nEnter valid operation\n\n");
        }
    }
}
